// Import required types
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Razorpay } from 'https://esm.sh/razorpay@2.8.6';

// Define types
interface OrderRequest {
  amount: number;
  currency?: string;
  receipt?: string;
  notes?: Record<string, string>;
}

interface OrderResponse {
  id: string;
  amount: number;
  currency: string;
  receipt: string;
  status: string;
  created_at: number;
}

interface ErrorResponse {
  error: string;
  details?: string | null;
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Initialize Razorpay client
const razorpay = new Razorpay({
  key_id: Deno.env.get('RAZORPAY_KEY_ID') || '',
  key_secret: Deno.env.get('RAZORPAY_KEY_SECRET') || '',
});

// Main handler function
async function handleRequest(req: Request): Promise<Response> {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Parse request body
    const { amount, currency = 'INR', receipt, notes } = await req.json() as OrderRequest;

    if (!amount) {
      return createErrorResponse('Amount is required', 400);
    }

    // Create order in Razorpay
    const order = await razorpay.orders.create({
      amount: Math.round(amount * 100), // Convert to paise
      currency,
      receipt: receipt || `order_rcpt_${Date.now()}`,
      notes,
      payment_capture: 1, // Auto-capture payment
    }) as OrderResponse;

    return new Response(
      JSON.stringify({
        id: order.id,
        amount: order.amount,
        currency: order.currency,
        receipt: order.receipt,
        status: order.status,
        created_at: order.created_at,
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  } catch (error) {
    console.error('Error creating Razorpay order:', error);
    return createErrorResponse(
      error instanceof Error ? error.message : 'Failed to create order',
      500,
      error instanceof Error ? error.message : undefined
    );
  }
}

// Helper function to create error responses
function createErrorResponse(
  error: string, 
  status: number, 
  details?: string
): Response {
  const response: ErrorResponse = { error };
  if (details) response.details = details;
  
  return new Response(
    JSON.stringify(response),
    { 
      status, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    }
  );
}

// Start the server
serve(handleRequest);
